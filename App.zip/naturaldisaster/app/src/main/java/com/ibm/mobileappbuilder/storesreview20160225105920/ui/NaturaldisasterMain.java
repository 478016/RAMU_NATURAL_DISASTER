package com.ibm.mobileappbuilder.storesreview20160225105920.ui;

import android.support.v4.app.Fragment;
import android.util.SparseArray;

import ibmmobileappbuilder.ui.DrawerActivity;

import com.ibm.mobileappbuilder.storesreview20160225105920.ds.StoresDSItem;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;

public class NaturaldisasterMain extends DrawerActivity {

    private final SparseArray<Class<? extends Fragment>> sectionFragments = new SparseArray<>();
    {
                sectionFragments.append(R.id.entry0, LocationsFragment.class);
            sectionFragments.append(R.id.entry1, IndutriesFragment.class);
            sectionFragments.append(R.id.entry2, RankingFragment.class);
            sectionFragments.append(R.id.entry3, EarthquakeproneareasFragment.class);
            sectionFragments.append(R.id.entry4, FloodsFragment.class);
    }

    @Override
    public SparseArray<Class<? extends Fragment>> getSectionFragmentClasses() {
      return sectionFragments;
    }

}

