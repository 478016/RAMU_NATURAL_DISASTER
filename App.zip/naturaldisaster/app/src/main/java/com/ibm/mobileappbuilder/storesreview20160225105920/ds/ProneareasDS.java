

package com.ibm.mobileappbuilder.storesreview20160225105920.ds;

import android.content.Context;

import java.net.URL;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.restds.AppNowDatasource;
import ibmmobileappbuilder.util.StringUtils;
import ibmmobileappbuilder.ds.restds.TypedByteArrayUtils;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import ibmmobileappbuilder.analytics.injector.NetworkLoggerInjector;
import ibmmobileappbuilder.analytics.injector.RetrofitResponseNetworkLoggerInjector;

/**
 * "ProneareasDS" data source. (e37eb8dc-6eb2-4635-8592-5eb9696050e3)
 */
public class ProneareasDS extends AppNowDatasource<ProneareasDSItem>{

    // default page size
    private static final int PAGE_SIZE = 20;

    private ProneareasDSService service;

    public static ProneareasDS getInstance(SearchOptions searchOptions){
        return new ProneareasDS(searchOptions);
    }

    private ProneareasDS(SearchOptions searchOptions) {
        super(searchOptions);
        this.service = ProneareasDSService.getInstance();
    }

    @Override
    public void getItem(String id, final Listener<ProneareasDSItem> listener) {
        if ("0".equals(id)) {
            NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS", "GET");
            getItems(new Listener<List<ProneareasDSItem>>() {
                @Override
                public void onSuccess(List<ProneareasDSItem> items) {
                    if(items != null && items.size() > 0) {
                        listener.onSuccess(items.get(0));
                    } else {
                        listener.onSuccess(new ProneareasDSItem());
                    }
                }

                @Override
                public void onFailure(Exception e) {
                    listener.onFailure(e);
                }
            });
        } else {
          NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS"+id, "GET");
            service.getServiceProxy().getProneareasDSItemById(id, new Callback<ProneareasDSItem>() {
                @Override
                public void success(ProneareasDSItem result, Response response) {
                    RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                    listener.onSuccess(result);
                }

                @Override
                public void failure(RetrofitError error) {
                    RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                    listener.onFailure(error);
                }
            });
        }
    }

    @Override
    public void getItems(final Listener<List<ProneareasDSItem>> listener) {
        getItems(0, listener);
    }

    @Override
    public void getItems(int pagenum, final Listener<List<ProneareasDSItem>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        int skipNum = pagenum * PAGE_SIZE;
        String skip = skipNum == 0 ? null : String.valueOf(skipNum);
        String limit = PAGE_SIZE == 0 ? null: String.valueOf(PAGE_SIZE);
        String sort = getSort(searchOptions);
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS?skip="+skip+"&limit="+limit+"&conditions="+conditions+"&sort="+sort+"&select=null&populate=null", "GET");
        service.getServiceProxy().queryProneareasDSItem(
                skip,
                limit,
                conditions,
                sort,
                null,
                null,
                new Callback<List<ProneareasDSItem>>() {
            @Override
            public void success(List<ProneareasDSItem> result, Response response) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                listener.onFailure(error);
            }
        });
    }

    private String[] getSearchableFields() {
        return new String[]{"text2", "text3"};
    }

    // Pagination

    @Override
    public int getPageSize(){
        return PAGE_SIZE;
    }

    @Override
    public void getUniqueValuesFor(String searchStr, final Listener<List<String>> listener) {
        String conditions = getConditions(searchOptions, getSearchableFields());
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS?distinct="+searchStr+"&conditions="+conditions, "GET");
        service.getServiceProxy().distinct(searchStr, conditions, new Callback<List<String>>() {
             @Override
             public void success(List<String> result, Response response) {
                 RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                 result.removeAll(Collections.<String>singleton(null));
                 listener.onSuccess(result);
             }

             @Override
             public void failure(RetrofitError error) {
                 RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                 listener.onFailure(error);
             }
        });
    }

    @Override
    public URL getImageUrl(String path) {
        return service.getImageUrl(path);
    }

    @Override
    public void create(ProneareasDSItem item, Listener<ProneareasDSItem> listener) {
      NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS", "POST");
              
        if(item.pictureUri != null){
            service.getServiceProxy().createProneareasDSItem(item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().createProneareasDSItem(item, callbackFor(listener));
        
    }

    private Callback<ProneareasDSItem> callbackFor(final Listener<ProneareasDSItem> listener) {
      return new Callback<ProneareasDSItem>() {
          @Override
          public void success(ProneareasDSItem item, Response response) {
              RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
              listener.onSuccess(item);
          }

          @Override
          public void failure(RetrofitError error) {
              RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
              listener.onFailure(error);
          }
      };
    }

    @Override
    public void updateItem(ProneareasDSItem item, Listener<ProneareasDSItem> listener) {
      NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS", "PUT");
              
        if(item.pictureUri != null){
            service.getServiceProxy().updateProneareasDSItem(item.getIdentifiableId(),
                item,
                TypedByteArrayUtils.fromUri(item.pictureUri),
                callbackFor(listener));
        }
        else
            service.getServiceProxy().updateProneareasDSItem(item.getIdentifiableId(), item, callbackFor(listener));
        
    }

    @Override
    public void deleteItem(ProneareasDSItem item, final Listener<ProneareasDSItem> listener) {
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS", "DELETE");
        service.getServiceProxy().deleteProneareasDSItemById(item.getIdentifiableId(), new Callback<ProneareasDSItem>() {
            @Override
            public void success(ProneareasDSItem result, Response response) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                listener.onSuccess(result);
            }

            @Override
            public void failure(RetrofitError error) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                listener.onFailure(error);
            }
        });
    }

    @Override
    public void deleteItems(List<ProneareasDSItem> items, final Listener<ProneareasDSItem> listener) {
        NetworkLoggerInjector.networkLogger().logRequest("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37/r/proneareasDS", "POST");
        service.getServiceProxy().deleteByIds(collectIds(items), new Callback<List<ProneareasDSItem>>() {
            @Override
            public void success(List<ProneareasDSItem> item, Response response) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(response);
                listener.onSuccess(null);
            }

            @Override
            public void failure(RetrofitError error) {
                RetrofitResponseNetworkLoggerInjector.retrofitNetworkLogger().logResponse(error.getResponse());
                listener.onFailure(error);
            }
        });
    }

    protected List<String> collectIds(List<ProneareasDSItem> items){
        List<String> ids = new ArrayList<>();
        for(ProneareasDSItem item: items){
            ids.add(item.getIdentifiableId());
        }
        return ids;
    }

}

