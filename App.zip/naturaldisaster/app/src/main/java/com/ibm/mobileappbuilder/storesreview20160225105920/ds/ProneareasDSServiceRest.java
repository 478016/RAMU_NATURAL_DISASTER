
package com.ibm.mobileappbuilder.storesreview20160225105920.ds;
import java.util.List;
import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
import retrofit.http.POST;
import retrofit.http.Body;
import retrofit.http.DELETE;
import retrofit.http.Path;
import retrofit.http.PUT;
import retrofit.mime.TypedByteArray;
import retrofit.http.Part;
import retrofit.http.Multipart;

public interface ProneareasDSServiceRest{

	@GET("/app/57ef635e9d17e00300d4da37/r/proneareasDS")
	void queryProneareasDSItem(
		@Query("skip") String skip,
		@Query("limit") String limit,
		@Query("conditions") String conditions,
		@Query("sort") String sort,
		@Query("select") String select,
		@Query("populate") String populate,
		Callback<List<ProneareasDSItem>> cb);

	@GET("/app/57ef635e9d17e00300d4da37/r/proneareasDS/{id}")
	void getProneareasDSItemById(@Path("id") String id, Callback<ProneareasDSItem> cb);

	@DELETE("/app/57ef635e9d17e00300d4da37/r/proneareasDS/{id}")
  void deleteProneareasDSItemById(@Path("id") String id, Callback<ProneareasDSItem> cb);

  @POST("/app/57ef635e9d17e00300d4da37/r/proneareasDS/deleteByIds")
  void deleteByIds(@Body List<String> ids, Callback<List<ProneareasDSItem>> cb);

  @POST("/app/57ef635e9d17e00300d4da37/r/proneareasDS")
  void createProneareasDSItem(@Body ProneareasDSItem item, Callback<ProneareasDSItem> cb);

  @PUT("/app/57ef635e9d17e00300d4da37/r/proneareasDS/{id}")
  void updateProneareasDSItem(@Path("id") String id, @Body ProneareasDSItem item, Callback<ProneareasDSItem> cb);

  @GET("/app/57ef635e9d17e00300d4da37/r/proneareasDS")
  void distinct(
        @Query("distinct") String colName,
        @Query("conditions") String conditions,
        Callback<List<String>> cb);
    
    @Multipart
    @POST("/app/57ef635e9d17e00300d4da37/r/proneareasDS")
    void createProneareasDSItem(
        @Part("data") ProneareasDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ProneareasDSItem> cb);
    
    @Multipart
    @PUT("/app/57ef635e9d17e00300d4da37/r/proneareasDS/{id}")
    void updateProneareasDSItem(
        @Path("id") String id,
        @Part("data") ProneareasDSItem item,
        @Part("picture") TypedByteArray picture,
        Callback<ProneareasDSItem> cb);
}

