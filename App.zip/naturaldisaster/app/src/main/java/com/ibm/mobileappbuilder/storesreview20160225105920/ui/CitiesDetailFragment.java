
package com.ibm.mobileappbuilder.storesreview20160225105920.ui;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.TextView;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.behaviors.ShareBehavior;
import ibmmobileappbuilder.ds.Datasource;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;
import ibmmobileappbuilder.analytics.AnalyticsReporter;
import static ibmmobileappbuilder.analytics.model.AnalyticsInfo.Builder.analyticsInfo;
import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;
import ibmmobileappbuilder.ds.SearchOptions;
import ibmmobileappbuilder.ds.filter.Filter;
import java.util.Arrays;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.Item;
import com.ibm.mobileappbuilder.storesreview20160225105920.ds.EmptyDatasource;

public class CitiesDetailFragment extends ibmmobileappbuilder.ui.DetailFragment<Item> implements ShareBehavior.ShareListener  {

    private Datasource<Item> datasource;
    private AnalyticsReporter analyticsReporter;
    public static CitiesDetailFragment newInstance(Bundle args){
        CitiesDetailFragment fr = new CitiesDetailFragment();
        fr.setArguments(args);

        return fr;
    }

    public CitiesDetailFragment(){
        super();
    }

    @Override
    public Datasource<Item> getDatasource() {
      if (datasource != null) {
        return datasource;
      }
       datasource = EmptyDatasource.getInstance(new SearchOptions());
        return datasource;
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
addBehavior(pageViewBehavior("citiesDetail"));
        analyticsReporter = AnalyticsReporterInjector.analyticsReporter(getActivity());
        addBehavior(new ShareBehavior(getActivity(), this));

    }

    // Bindings

    @Override
    protected int getLayout() {
        return R.layout.citiesdetail_detail;
    }

    @Override
    @SuppressLint("WrongViewCast")
    public void bindView(final Item item, View view) {
        
        TextView view0 = (TextView) view.findViewById(R.id.view0);
        view0.setText("thiruvallur,perambur ,chennai some areas are heavily affected areas");
        
        
        TextView view1 = (TextView) view.findViewById(R.id.view1);
        view1.setText("rate of disaster is 4.5,");
        
    }

    @Override
    protected void onShow(Item item) {
        // set the title for this fragment
        getActivity().setTitle("chennai");
    }
    @Override
    public void onShare() {
        Item item = getItem();

        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_SEND);
        intent.setType("text/plain");

        intent.putExtra(Intent.EXTRA_TEXT, "thiruvallur,perambur ,chennai some areas are heavily affected areas" + "\n" +
                    "rate of disaster is 4.5,");
        intent.putExtra(Intent.EXTRA_SUBJECT, "chennai");
        analyticsReporter.sendEvent(analyticsInfo()
                            .withAction("share")
                            .withTarget("thiruvallur,perambur ,chennai some areas are heavily affected areas" + "\n" +
                    "rate of disaster is 4.5,")
                            .withDataSource("EmptyDatasource")
                            .build().toMap()
        );
        startActivityForResult(Intent.createChooser(intent, getString(R.string.share)), 1);
    }
}

