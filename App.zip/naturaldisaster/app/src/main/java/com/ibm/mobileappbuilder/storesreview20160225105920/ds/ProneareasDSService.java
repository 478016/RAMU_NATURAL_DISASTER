
package com.ibm.mobileappbuilder.storesreview20160225105920.ds;
import java.net.URL;
import com.ibm.mobileappbuilder.storesreview20160225105920.R;
import ibmmobileappbuilder.ds.RestService;
import ibmmobileappbuilder.util.StringUtils;

/**
 * "ProneareasDSService" REST Service implementation
 */
public class ProneareasDSService extends RestService<ProneareasDSServiceRest>{

    public static ProneareasDSService getInstance(){
          return new ProneareasDSService();
    }

    private ProneareasDSService() {
        super(ProneareasDSServiceRest.class);

    }

    @Override
    public String getServerUrl() {
        return "https://ibm-pods.buildup.io";
    }

    @Override
    protected String getApiKey() {
        return "M31K5CDd";
    }

    @Override
    public URL getImageUrl(String path){
        return StringUtils.parseUrl("https://ibm-pods.buildup.io/app/57ef635e9d17e00300d4da37",
                path,
                "apikey=M31K5CDd");
    }

}

